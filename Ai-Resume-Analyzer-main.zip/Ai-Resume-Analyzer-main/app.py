from flask import Flask, render_template, request, jsonify, send_file
import os
import tempfile
from werkzeug.utils import secure_filename
from utils.extract_text import extract_text_from_file
from utils.ats_score import calculate_ats_score, analyze_skills_match
from utils.optimizer import generate_suggestions, create_optimized_resume
import json

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['UPLOAD_FOLDER'] = 'temp_uploads'

# Create upload folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'pdf', 'docx', 'doc', 'txt'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze_resume():
    try:
        # Get job description
        job_description = request.form.get('job_description', '').strip()
        if not job_description:
            return jsonify({'error': 'Job description is required'}), 400

        # Handle file upload
        if 'resume_file' not in request.files:
            return jsonify({'error': 'No resume file uploaded'}), 400
        
        file = request.files['resume_file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400

        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Please upload PDF, DOCX, DOC, or TXT files.'}), 400

        # Save uploaded file temporarily
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        try:
            # Extract text from resume
            resume_text = extract_text_from_file(filepath)
            
            if not resume_text.strip():
                return jsonify({'error': 'Could not extract text from the resume file'}), 400

            # Perform analysis
            ats_score = calculate_ats_score(resume_text, job_description)
            skills_analysis = analyze_skills_match(resume_text, job_description)
            suggestions = generate_suggestions(resume_text, job_description, skills_analysis)

            # Prepare results
            results = {
                'ats_score': ats_score,
                'skill_match_percentage': skills_analysis['match_percentage'],
                'matched_skills': skills_analysis['matched_skills'],
                'missing_skills': skills_analysis['missing_skills'],
                'suggestions': suggestions,
                'resume_text': resume_text[:500] + '...' if len(resume_text) > 500 else resume_text
            }

            return render_template('result.html', results=results, job_description=job_description)

        finally:
            # Clean up uploaded file
            if os.path.exists(filepath):
                os.remove(filepath)

    except Exception as e:
        return jsonify({'error': f'An error occurred: {str(e)}'}), 500

@app.route('/download-optimized', methods=['POST'])
def download_optimized_resume():
    try:
        data = request.get_json()
        resume_text = data.get('resume_text', '')
        suggestions = data.get('suggestions', [])
        
        if not resume_text:
            return jsonify({'error': 'Resume text is required'}), 400

        # Create optimized resume
        optimized_file = create_optimized_resume(resume_text, suggestions)
        
        return send_file(
            optimized_file,
            as_attachment=True,
            download_name='optimized_resume.docx',
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )

    except Exception as e:
        return jsonify({'error': f'Failed to create optimized resume: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True)

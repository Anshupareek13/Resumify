import re
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# Common technical skills and keywords
TECHNICAL_SKILLS = {
    'programming': ['python', 'java', 'javascript', 'c++', 'c#', 'php', 'ruby', 'go', 'rust', 'swift', 'kotlin'],
    'web': ['html', 'css', 'react', 'angular', 'vue', 'node.js', 'express', 'django', 'flask', 'spring'],
    'database': ['sql', 'mysql', 'postgresql', 'mongodb', 'redis', 'elasticsearch', 'oracle', 'sqlite'],
    'cloud': ['aws', 'azure', 'gcp', 'docker', 'kubernetes', 'terraform', 'jenkins', 'ci/cd'],
    'data': ['pandas', 'numpy', 'scikit-learn', 'tensorflow', 'pytorch', 'tableau', 'power bi', 'excel'],
    'tools': ['git', 'jira', 'confluence', 'slack', 'trello', 'figma', 'photoshop', 'illustrator']
}

def calculate_ats_score(resume_text, job_description):
    """Calculate ATS compatibility score based on multiple factors"""
    resume_lower = resume_text.lower()
    job_lower = job_description.lower()
    
    scores = {}
    
    # 1. Keyword matching (40% weight)
    keyword_score = calculate_keyword_match(resume_lower, job_lower)
    scores['keyword_match'] = keyword_score * 0.4
    
    # 2. Skills matching (30% weight)
    skills_score = calculate_skills_match(resume_lower, job_lower)
    scores['skills_match'] = skills_score * 0.3
    
    # 3. Text similarity (20% weight)
    similarity_score = calculate_text_similarity(resume_text, job_description)
    scores['text_similarity'] = similarity_score * 0.2
    
    # 4. Format and structure (10% weight)
    format_score = calculate_format_score(resume_text)
    scores['format_score'] = format_score * 0.1
    
    total_score = sum(scores.values())
    return min(100, max(0, int(total_score)))

def calculate_keyword_match(resume_text, job_description):
    """Calculate keyword matching percentage"""
    # Extract important keywords from job description
    job_keywords = extract_keywords(job_description)
    resume_keywords = extract_keywords(resume_text)
    
    if not job_keywords:
        return 0
    
    matched_keywords = set(job_keywords) & set(resume_keywords)
    match_percentage = (len(matched_keywords) / len(job_keywords)) * 100
    
    return min(100, match_percentage)

def calculate_skills_match(resume_text, job_description):
    """Calculate technical skills matching"""
    job_skills = extract_technical_skills(job_description)
    resume_skills = extract_technical_skills(resume_text)
    
    if not job_skills:
        return 50  # Default score if no skills found
    
    matched_skills = set(job_skills) & set(resume_skills)
    match_percentage = (len(matched_skills) / len(job_skills)) * 100
    
    return min(100, match_percentage)

def calculate_text_similarity(resume_text, job_description):
    """Calculate cosine similarity between texts"""
    try:
        vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
        tfidf_matrix = vectorizer.fit_transform([resume_text, job_description])
        similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        return similarity * 100
    except:
        return 0

def calculate_format_score(resume_text):
    """Calculate format and structure score"""
    score = 0
    
    # Check for common resume sections
    sections = ['experience', 'education', 'skills', 'summary', 'objective']
    for section in sections:
        if section in resume_text.lower():
            score += 10
    
    # Check for contact information
    if re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', resume_text):
        score += 10
    
    # Check for phone number
    if re.search(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', resume_text):
        score += 10
    
    # Check for proper length (not too short, not too long)
    word_count = len(resume_text.split())
    if 200 <= word_count <= 1000:
        score += 20
    
    return min(100, score)

def extract_keywords(text):
    """Extract important keywords from text"""
    # Remove common stop words and extract meaningful terms
    words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
    
    # Filter out very common words
    stop_words = {'the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'had', 'her', 'was', 'one', 'our', 'out', 'day', 'get', 'has', 'him', 'his', 'how', 'man', 'new', 'now', 'old', 'see', 'two', 'way', 'who', 'boy', 'did', 'its', 'let', 'put', 'say', 'she', 'too', 'use'}
    
    keywords = [word for word in words if word not in stop_words and len(word) > 3]
    
    # Return most common keywords
    counter = Counter(keywords)
    return [word for word, count in counter.most_common(50)]

def extract_technical_skills(text):
    """Extract technical skills from text"""
    skills = []
    text_lower = text.lower()
    
    for category, skill_list in TECHNICAL_SKILLS.items():
        for skill in skill_list:
            if skill in text_lower:
                skills.append(skill)
    
    return list(set(skills))

def analyze_skills_match(resume_text, job_description):
    """Detailed skills analysis"""
    job_skills = extract_technical_skills(job_description.lower())
    resume_skills = extract_technical_skills(resume_text.lower())
    
    matched_skills = list(set(job_skills) & set(resume_skills))
    missing_skills = list(set(job_skills) - set(resume_skills))
    
    match_percentage = 0
    if job_skills:
        match_percentage = (len(matched_skills) / len(job_skills)) * 100
    
    return {
        'matched_skills': matched_skills,
        'missing_skills': missing_skills,
        'match_percentage': round(match_percentage, 1),
        'total_job_skills': len(job_skills),
        'total_resume_skills': len(resume_skills)
    }

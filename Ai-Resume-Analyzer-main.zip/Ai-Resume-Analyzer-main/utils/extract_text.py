import os
from pdfminer.high_level import extract_text as pdf_extract_text
from docx import Document
import re

def extract_text_from_file(filepath):
    """Extract text from PDF, DOCX, DOC, or TXT files"""
    try:
        file_extension = os.path.splitext(filepath)[1].lower()
        
        if file_extension == '.pdf':
            return extract_text_from_pdf(filepath)
        elif file_extension in ['.docx', '.doc']:
            return extract_text_from_docx(filepath)
        elif file_extension == '.txt':
            return extract_text_from_txt(filepath)
        else:
            raise ValueError(f"Unsupported file type: {file_extension}")
    
    except Exception as e:
        raise Exception(f"Error extracting text from file: {str(e)}")

def extract_text_from_pdf(filepath):
    """Extract text from PDF file"""
    try:
        text = pdf_extract_text(filepath)
        return clean_text(text)
    except Exception as e:
        raise Exception(f"Error reading PDF file: {str(e)}")

def extract_text_from_docx(filepath):
    """Extract text from DOCX file"""
    try:
        doc = Document(filepath)
        text = []
        for paragraph in doc.paragraphs:
            text.append(paragraph.text)
        return clean_text('\n'.join(text))
    except Exception as e:
        raise Exception(f"Error reading DOCX file: {str(e)}")

def extract_text_from_txt(filepath):
    """Extract text from TXT file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            text = file.read()
        return clean_text(text)
    except Exception as e:
        try:
            # Try with different encoding
            with open(filepath, 'r', encoding='latin-1') as file:
                text = file.read()
            return clean_text(text)
        except Exception as e2:
            raise Exception(f"Error reading TXT file: {str(e2)}")

def clean_text(text):
    """Clean and normalize extracted text"""
    if not text:
        return ""
    
    # Remove extra whitespace and normalize line breaks
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'\n+', '\n', text)
    
    # Remove special characters but keep important punctuation
    text = re.sub(r'[^\w\s\.\,\;\:\-$$$$\@\#\+]', ' ', text)
    
    return text.strip()

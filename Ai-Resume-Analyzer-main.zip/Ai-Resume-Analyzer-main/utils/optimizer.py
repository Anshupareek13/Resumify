import tempfile
import os
from docx import Document
from docx.shared import Inches
import re

def generate_suggestions(resume_text, job_description, skills_analysis):
    """Generate improvement suggestions for the resume"""
    suggestions = []
    
    # Missing skills suggestions
    if skills_analysis['missing_skills']:
        missing_skills_str = ', '.join(skills_analysis['missing_skills'][:5])
        suggestions.append({
            'type': 'skills',
            'title': 'Add Missing Technical Skills',
            'description': f"Consider adding these skills to your resume: {missing_skills_str}",
            'priority': 'high'
        })
    
    # Keyword optimization
    job_keywords = extract_important_keywords(job_description)
    resume_keywords = extract_important_keywords(resume_text)
    missing_keywords = list(set(job_keywords) - set(resume_keywords))
    
    if missing_keywords:
        missing_keywords_str = ', '.join(missing_keywords[:5])
        suggestions.append({
            'type': 'keywords',
            'title': 'Include Relevant Keywords',
            'description': f"Add these keywords naturally throughout your resume: {missing_keywords_str}",
            'priority': 'high'
        })
    
    # Format suggestions
    format_suggestions = analyze_format_issues(resume_text)
    suggestions.extend(format_suggestions)
    
    # Content suggestions
    content_suggestions = analyze_content_issues(resume_text, job_description)
    suggestions.extend(content_suggestions)
    
    return suggestions

def extract_important_keywords(text):
    """Extract important keywords for optimization"""
    # Focus on nouns and technical terms
    words = re.findall(r'\b[A-Z][a-z]+\b|\b[a-z]{4,}\b', text)
    
    # Filter technical and business terms
    important_words = []
    for word in words:
        word_lower = word.lower()
        if (len(word) >= 4 and 
            word_lower not in ['this', 'that', 'with', 'from', 'they', 'have', 'will', 'been', 'were', 'said', 'each', 'which', 'their', 'time', 'would', 'there', 'could', 'other']):
            important_words.append(word_lower)
    
    # Return unique keywords
    return list(set(important_words))

def analyze_format_issues(resume_text):
    """Analyze resume format and structure issues"""
    suggestions = []
    
    # Check for contact information
    if not re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', resume_text):
        suggestions.append({
            'type': 'format',
            'title': 'Add Email Address',
            'description': 'Include a professional email address in your contact information',
            'priority': 'high'
        })
    
    # Check for phone number
    if not re.search(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', resume_text):
        suggestions.append({
            'type': 'format',
            'title': 'Add Phone Number',
            'description': 'Include your phone number in the contact section',
            'priority': 'medium'
        })
    
    # Check for sections
    required_sections = ['experience', 'education', 'skills']
    for section in required_sections:
        if section not in resume_text.lower():
            suggestions.append({
                'type': 'format',
                'title': f'Add {section.title()} Section',
                'description': f'Include a dedicated {section} section in your resume',
                'priority': 'high'
            })
    
    # Check resume length
    word_count = len(resume_text.split())
    if word_count < 200:
        suggestions.append({
            'type': 'format',
            'title': 'Expand Resume Content',
            'description': 'Your resume appears too brief. Add more details about your experience and achievements',
            'priority': 'medium'
        })
    elif word_count > 1000:
        suggestions.append({
            'type': 'format',
            'title': 'Condense Resume Content',
            'description': 'Your resume may be too long. Focus on the most relevant information',
            'priority': 'low'
        })
    
    return suggestions

def analyze_content_issues(resume_text, job_description):
    """Analyze content-related issues"""
    suggestions = []
    
    # Check for quantifiable achievements
    if not re.search(r'\d+%|\$\d+|\d+\s*(years?|months?)', resume_text):
        suggestions.append({
            'type': 'content',
            'title': 'Add Quantifiable Achievements',
            'description': 'Include specific numbers, percentages, or metrics to demonstrate your impact',
            'priority': 'high'
        })
    
    # Check for action verbs
    action_verbs = ['managed', 'developed', 'created', 'implemented', 'improved', 'increased', 'reduced', 'led', 'designed', 'built']
    found_verbs = [verb for verb in action_verbs if verb in resume_text.lower()]
    
    if len(found_verbs) < 3:
        suggestions.append({
            'type': 'content',
            'title': 'Use Strong Action Verbs',
            'description': 'Start bullet points with strong action verbs like "managed," "developed," "implemented"',
            'priority': 'medium'
        })
    
    # Check for industry-specific terms
    if 'software' in job_description.lower() or 'developer' in job_description.lower():
        tech_terms = ['api', 'database', 'framework', 'algorithm', 'debugging', 'testing']
        found_tech_terms = [term for term in tech_terms if term in resume_text.lower()]
        
        if len(found_tech_terms) < 2:
            suggestions.append({
                'type': 'content',
                'title': 'Include Technical Terminology',
                'description': 'Add more technical terms relevant to software development',
                'priority': 'medium'
            })
    
    return suggestions

def create_optimized_resume(resume_text, suggestions):
    """Create an optimized resume document"""
    try:
        # Create a new document
        doc = Document()
        
        # Add title
        title = doc.add_heading('Optimized Resume', 0)
        title.alignment = 1  # Center alignment
        
        # Add original content
        doc.add_heading('Resume Content', level=1)
        
        # Split resume into paragraphs and add them
        paragraphs = resume_text.split('\n')
        for paragraph in paragraphs:
            if paragraph.strip():
                doc.add_paragraph(paragraph.strip())
        
        # Add suggestions section
        doc.add_page_break()
        doc.add_heading('Optimization Suggestions', level=1)
        
        for i, suggestion in enumerate(suggestions, 1):
            doc.add_heading(f"{i}. {suggestion['title']}", level=2)
            doc.add_paragraph(f"Priority: {suggestion['priority'].upper()}")
            doc.add_paragraph(suggestion['description'])
            doc.add_paragraph()  # Add space
        
        # Save to temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.docx')
        doc.save(temp_file.name)
        temp_file.close()
        
        return temp_file.name
        
    except Exception as e:
        raise Exception(f"Error creating optimized resume: {str(e)}")
